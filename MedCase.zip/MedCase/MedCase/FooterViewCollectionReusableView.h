//
//  FooterViewCollectionReusableView.h
//  MedicalRecord
//
//  Created by ihefe-JF on 15/1/4.
//  Copyright (c) 2015年 JFAppHourse.app. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FooterViewCollectionReusableView : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UIButton *FooterViewButton;

@end
