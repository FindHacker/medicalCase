//
//  NSArray+Extension.h
//  MedicalRecord
//
//  Created by ihefe-JF on 15/1/4.
//  Copyright (c) 2015年 JFAppHourse.app. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray(Extensions)

-(NSArray*)difference:(NSArray*)values;
-(instancetype)insert:(NSString*)tempStr;
@end
