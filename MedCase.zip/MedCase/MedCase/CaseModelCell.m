//
//  CaseModelCell.m
//  MedCase
//
//  Created by ihefe-JF on 15/1/29.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import "CaseModelCell.h"

@implementation CaseModelCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
