//
//  TestFlowLayout.h
//  MedCase
//
//  Created by ihefe-JF on 15/2/13.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestFlowLayout : UICollectionViewFlowLayout

@end
