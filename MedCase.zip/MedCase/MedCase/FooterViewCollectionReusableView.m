//
//  FooterViewCollectionReusableView.m
//  MedicalRecord
//
//  Created by ihefe-JF on 15/1/4.
//  Copyright (c) 2015年 JFAppHourse.app. All rights reserved.
//

#import "FooterViewCollectionReusableView.h"

@implementation FooterViewCollectionReusableView

@end
