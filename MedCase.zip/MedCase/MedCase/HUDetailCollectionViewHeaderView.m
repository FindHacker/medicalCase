//
//  HUDetailCollectionViewHeaderViewCollectionReusableView.m
//  MedCase
//
//  Created by ihefe-JF on 15/1/6.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import "HUDetailCollectionViewHeaderView.h"

@implementation HUDetailCollectionViewHeaderView


@end
