//
//  NotificationConfig.h
//  MedCase
//
//  Created by ihefe36 on 15/1/24.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#ifndef MedCase_NotificationConfig_h
#define MedCase_NotificationConfig_h

#define nShouldReloadNodeTableView @"nShouldReloadNodeTableView" //节点列表更新tableview，选中某一cell后发出

#endif
