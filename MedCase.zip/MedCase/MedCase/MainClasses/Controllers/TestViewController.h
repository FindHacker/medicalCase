//
//  TestViewController.h
//  MedCase
//
//  Created by ihefe36 on 15/1/6.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WLKMultiTableView.h"

@interface TestViewController : UIViewController

@property (weak, nonatomic) IBOutlet WLKMultiTableView *multiTableView;

FOUNDATION_EXPORT NSString  * const kMyConstantString;
@end
