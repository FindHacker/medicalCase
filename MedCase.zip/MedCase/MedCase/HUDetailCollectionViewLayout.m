//
//  HUDetailCollectionViewLayout.m
//  MedCase
//
//  Created by ihefe-JF on 15/1/5.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import "HUDetailCollectionViewLayout.h"

@implementation HUDetailCollectionViewLayout

@end
