//
//  PersonTableViewController.h
//  MedicalRecord
//
//  Created by ihefe-JF on 14/12/26.
//  Copyright (c) 2014年 JFAppHourse.app. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonTableViewController : UITableViewController 

@end
