//
//  WLKDatabaseHelper.m
//  MedImageReader
//
//  Created by ihefe36 on 14/12/24.
//  Copyright (c) 2014年 ihefe. All rights reserved.
//

#import "WLKDatabaseHelper.h"

@implementation WLKDatabaseHelper

- (WLKCase *)getCaseByID:(NSString *)ID
{
    return nil;
}

@end
