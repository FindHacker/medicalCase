//
//  NetConfig.h
//  MedCase
//
//  Created by ihefe36 on 15/1/28.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#ifndef MedCase_NetConfig_h
#define MedCase_NetConfig_h

#define Server_IP @"192.168.10.106"
#define Server_Port 2323

#endif
