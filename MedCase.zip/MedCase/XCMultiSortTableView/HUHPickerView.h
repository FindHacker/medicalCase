//
//  HUHPickerView.h
//  XCMultiSortTableDemo
//
//  Created by ihefe-JF on 15/3/4.
//  Copyright (c) 2015年 Kingiol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HUHPickerView : UIView

@end
