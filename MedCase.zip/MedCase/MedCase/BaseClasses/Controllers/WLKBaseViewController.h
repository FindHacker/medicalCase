//
//  WLKBaseViewController.h
//  MedCase
//
//  Created by ihefe36 on 15/1/4.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WLKBaseViewController : UIViewController

@end
