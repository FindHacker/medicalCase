//
//  RawCaseData.m
//  MedCase
//
//  Created by ihefe-JF on 15/2/6.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import "RawCaseData.h"


@implementation RawCaseData

@dynamic caseContent;
@dynamic updateTime;
@dynamic createTime;

@end
