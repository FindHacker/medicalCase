//
//  HUHPickerView.m
//  XCMultiSortTableDemo
//
//  Created by ihefe-JF on 15/3/4.
//  Copyright (c) 2015年 Kingiol. All rights reserved.
//

#import "HUHPickerView.h"

@implementation HUHPickerView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
